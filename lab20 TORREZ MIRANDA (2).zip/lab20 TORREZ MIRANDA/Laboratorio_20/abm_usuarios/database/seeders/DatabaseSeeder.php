<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UsuarioSeeder extends Seeder
{
    public function run(): void
    {
        // Usuario del ejemplo
        User::create([
            'name' => 'omarqm',
            'email' => 'omarqm@ejemplo.com',
            'password' => Hash::make('Omar411'),
            'nombre_completo' => 'Omar Quispe',
            'role' => 'admin',
        ]);

        // 4 Usuarios adicionales
        User::create([
            'name' => 'Maria',
            'email' => 'maria@ejemplo.com',
            'password' => Hash::make('Maria123'),
            'nombre_completo' => 'María López Rodríguez',
            'role' => 'usuario',
        ]);

        User::create([
            'name' => 'Carlos',
            'email' => 'carlos@ejemplo.com',
            'password' => Hash::make('Carlos456'),
            'nombre_completo' => 'Carlos Andrés Ruiz',
            'role' => 'usuario',
        ]);

        User::create([
            'name' => 'Ana',
            'email' => 'ana@ejemplo.com',
            'password' => Hash::make('Ana789'),
            'nombre_completo' => 'Ana Isabel Torres',
            'role' => 'usuario',
        ]);

        User::create([
            'name' => 'Luis',
            'email' => 'luis@ejemplo.com',
            'password' => Hash::make('Luis101'),
            'nombre_completo' => 'Luis Fernando Mendoza',
            'role' => 'usuario',
        ]);

        $this->command->info('✅ 5 usuarios creados correctamente!');
    }
}