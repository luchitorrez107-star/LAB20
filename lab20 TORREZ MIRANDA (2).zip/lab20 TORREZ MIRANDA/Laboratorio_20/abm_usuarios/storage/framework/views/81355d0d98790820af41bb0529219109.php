<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 10px; }
        h2 { text-align: center; margin-bottom: 20px; }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #ffc107; color: black; border: none; border-radius: 5px; margin-top: 20px; cursor: pointer; }
        .volver { display: block; text-align: center; margin-top: 15px; color: #666; }
        .error { color: red; font-size: 12px; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>✏️ Editar Usuario</h2>
        <form action="<?php echo e(route('admin.usuarios.update', $usuario->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <label>Usuario:</label>
            <input type="text" name="name" value="<?php echo e($usuario->name); ?>" required>
            
            <label>Nombre Completo:</label>
            <input type="text" name="nombre_completo" value="<?php echo e($usuario->nombre_completo); ?>" required>
            
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo e($usuario->email); ?>" required>
            
            <label>Nueva Contraseña (opcional):</label>
            <input type="password" name="password">
            
            <label>Rol:</label>
            <select name="rol" required>
                <option value="usuario" <?php echo e($usuario->rol == 'usuario' ? 'selected' : ''); ?>>Usuario</option>
                <option value="admin" <?php echo e($usuario->rol == 'admin' ? 'selected' : ''); ?>>Administrador</option>
            </select>
            
            <button type="submit">🔄 Actualizar</button>
        </form>
        <a href="<?php echo e(route('admin.usuarios')); ?>" class="volver">← Volver</a>
    </div>
</body>
</html><?php /**PATH C:\Users\LUIS\Downloads\lab20 TORREZ MIRANDA\Laboratorio_20\abm_usuarios\resources\views/admin/usuarios/edit.blade.php ENDPATH**/ ?>