<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Usuario</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { max-width: 600px; margin: 50px auto; background: white; padding: 30px; border-radius: 10px; }
        h2 { text-align: center; margin-bottom: 20px; }
        label { display: block; margin-top: 10px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 5px; margin-top: 20px; cursor: pointer; }
        .volver { display: block; text-align: center; margin-top: 15px; color: #666; }
        .error { color: red; font-size: 12px; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>➕ Crear Nuevo Usuario</h2>
        <form action="{{ route('admin.usuarios.store') }}" method="POST">
            @csrf
            <label>Usuario:</label>
            <input type="text" name="name" required>
            @error('name') <p class="error">{{ $message }}</p> @enderror

            <label>Nombre Completo:</label>
            <input type="text" name="nombre_completo" required>
            @error('nombre_completo') <p class="error">{{ $message }}</p> @enderror

            <label>Email:</label>
            <input type="email" name="email" required>
            @error('email') <p class="error">{{ $message }}</p> @enderror

            <label>Contraseña:</label>
            <input type="password" name="password" required>
            @error('password') <p class="error">{{ $message }}</p> @enderror

            <label>Rol:</label>
            <select name="rol" required>
                <option value="usuario">Usuario</option>
                <option value="admin">Administrador</option>
            </select>

            <button type="submit">💾 Guardar</button>
        </form>
        <a href="{{ route('admin.usuarios') }}" class="volver">← Volver</a>
    </div>
</body>
</html>