<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .sidebar { width: 250px; background: #2c3e50; color: white; position: fixed; height: 100%; padding: 20px; }
        .sidebar h2 { text-align: center; margin-bottom: 30px; }
        .sidebar a { display: block; color: white; text-decoration: none; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .sidebar a:hover { background: #34495e; }
        .content { margin-left: 250px; padding: 20px; }
        .header { background: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .btn { padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: black; }
        .btn-danger { background: #dc3545; color: white; }
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 5px; overflow: hidden; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #3498db; color: white; }
        .badge-admin { background: #e74c3c; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }
        .badge-user { background: #2ecc71; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Panel Admin</h2>
        <a href="{{ route('admin.usuarios') }}">👥 Gestionar Usuarios</a>
        <hr style="margin: 10px 0;">
        <a href="{{ route('perfil') }}">👤 Mi Perfil</a>
        <hr style="margin: 10px 0;">
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" style="width:100%; background:#e74c3c; color:white; border:none; padding:10px; border-radius:5px; cursor:pointer;">
                🚪 Cerrar Sesión
            </button>
        </form>
    </div>

    <div class="content">
        <div class="header">
            <h1>Gestión de Usuarios</h1>
            <p><strong>{{ Auth::user()->nombre_completo }}</strong> ({{ Auth::user()->rol }})</p>
        </div>

        @if(session('success'))
            <div class="success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="error">{{ session('error') }}</div>
        @endif

        <a href="{{ route('admin.usuarios.create') }}" class="btn btn-success" style="margin-bottom: 15px;">➕ Nuevo Usuario</a>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Nombre Completo</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($usuarios as $usuario)
                <tr>
                    <td>{{ $usuario->id }}</td>
                    <td>{{ $usuario->name }}</td>
                    <td>{{ $usuario->nombre_completo }}</td>
                    <td>{{ $usuario->email }}</td>
                    <td>
                        @if($usuario->rol == 'admin')
                            <span class="badge-admin">Administrador</span>
                        @else
                            <span class="badge-user">Usuario</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.usuarios.edit', $usuario->id) }}" class="btn btn-warning">✏️ Editar</a>
                        @if($usuario->id != Auth::id())
                        <form action="{{ route('admin.usuarios.destroy', $usuario->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger" onclick="return confirm('¿Eliminar?')">🗑️ Eliminar</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>