<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { max-width: 800px; margin: 50px auto; }
        .card { background: white; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: #3498db; color: white; padding: 20px; text-align: center; }
        .body { padding: 30px; }
        .info { margin-bottom: 15px; padding: 10px; border-bottom: 1px solid #eee; }
        .label { font-weight: bold; color: #555; width: 150px; display: inline-block; }
        .value { color: #333; }
        .logout { display: block; width: 200px; margin: 20px auto; background: #e74c3c; color: white; text-align: center; padding: 10px; border-radius: 5px; text-decoration: none; border: none; cursor: pointer; }
        .logout:hover { background: #c0392b; }
        .btn-admin { display: block; width: 250px; margin: 10px auto; background: #2c3e50; color: white; text-align: center; padding: 10px; border-radius: 5px; text-decoration: none; }
        .btn-admin:hover { background: #1a252f; }
        .badge-admin { background: #e74c3c; color: white; padding: 3px 8px; border-radius: 3px; }
        .badge-user { background: #2ecc71; color: white; padding: 3px 8px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>Mi Perfil</h1>
                <p>LUIS ANGEL TORREZ MIRANDA - Sistema de Gestión</p>
            </div>
            <div class="body">
                <div class="info">
                    <span class="label">Usuario:</span>
                    <span class="value">{{ $usuario->name }}</span>
                </div>
                <div class="info">
                    <span class="label">Nombre Completo:</span>
                    <span class="value">{{ $usuario->nombre_completo }}</span>
                </div>
                <div class="info">
                    <span class="label">Email:</span>
                    <span class="value">{{ $usuario->email }}</span>
                </div>
                <div class="info">
                    <span class="label">Rol:</span>
                    <span class="value">
                        @if($usuario->rol == 'admin')
                            <span class="badge-admin">Administrador</span>
                        @else
                            <span class="badge-user">Usuario</span>
                        @endif
                    </span>
                </div>
                <div class="info">
                    <span class="label">Miembro desde:</span>
                    <span class="value">{{ $usuario->created_at->format('d/m/Y H:i:s') }}</span>
                </div>

                @if($usuario->isAdmin())
                    <a href="{{ route('admin.usuarios') }}" class="btn-admin">🔧 Panel de Administración</a>
                @endif

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="logout">🚪 Cerrar Sesión</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
